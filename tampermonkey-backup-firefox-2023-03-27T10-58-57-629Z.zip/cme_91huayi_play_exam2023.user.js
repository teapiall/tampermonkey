// ==UserScript==
// @name         cme_91huayi_play_exam2023
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       wechat
// @match        *://*.91huayi.com/pages/exam.aspx?*
// @match        *://*.91huayi.com/pages/exam_result.aspx?*
// @match        *://*.91huayi.com/course_ware/course_ware_polyv.aspx?*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    addCourseWarePlayRecord();
        window.location.href = "../pages/exam.aspx?cwid=" + cwrid;
   

})();
